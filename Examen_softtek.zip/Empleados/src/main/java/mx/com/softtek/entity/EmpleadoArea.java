package mx.com.softtek.entity;

public class EmpleadoArea {

	private int idEmpleado;
	private String cve_area;
	
	public Integer getIdEmpleado() {
		return idEmpleado;
	}
	public void setIdEmpleado(Integer idEmpleado) {
		this.idEmpleado = idEmpleado;
	}
	public String getCve_area() {
		return cve_area;
	}
	public void setCve_area(String cve_area) {
		this.cve_area = cve_area;
	}

}
