package mx.com.softtek.service;

import java.util.List;

import mx.com.softtek.entity.Area;

public interface AreaService {

	List<Area> obtenerAreas();
}
