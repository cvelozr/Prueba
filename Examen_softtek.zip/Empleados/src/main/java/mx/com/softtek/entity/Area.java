package mx.com.softtek.entity;

public class Area {

	private String cveArea;
	private String descripcion;
	public String getCveArea() {
		return cveArea;
	}
	public void setCveArea(String cveArea) {
		this.cveArea = cveArea;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
}
