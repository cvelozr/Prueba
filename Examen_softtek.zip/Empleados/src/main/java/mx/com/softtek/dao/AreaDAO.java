package mx.com.softtek.dao;

import java.util.List;

import mx.com.softtek.entity.Area;

public interface AreaDAO {
	List<Area> obtenerAreas();
}
